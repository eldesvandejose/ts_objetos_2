/* Creamos un tipo de datos personalizado, que es una lista. */
type actor = {nombre:string, nacimiento:string, peliculas:string[]};

/* Creamos una matriz llamada actores, en la que cada objeto es una estructura del tipo actor */
let actores: actor[] = [
  {
    nombre: "John Travolta",
    nacimiento: "18-02-1954",
    peliculas: [
      "Fiebre del sábado noche",
      "Grease",
      "Pulp Fiction",
      "El castigador",
      "Asalto al tren Pelham 123"
    ]
  },
  {
    nombre: "Natalie Portman",
    nacimiento: "09-06-1981",
    peliculas: [
        "Thor: Un Mundo Oscuro", 
        "Una loca aventura medieval", 
        "Star Wars: Episodio III - La venganza de los Sith", 
        "V de Vendetta", 
        "Star Wars: Episodio II - El ataque de los clones"]
  },
  {
    nombre: "Jennifer Garner",
    nacimiento: "17-04-1972",
    peliculas: [
        "Daredevil", 
        "La extraña vida de Timothy Green", 
        "Elektra", 
        "Valentine's Day", 
        "Nueve vidas"
    ]
  },
  {
    nombre: "Sean Connery",
    nacimiento: "25-08-1930",
    peliculas: [
        "La caza del Octubre Rojo", 
        "Los inmortales", 
        "Desde Rusia con amor", 
        "Sólo se vive dos veces", 
        "Atmósfera cero"
    ]
  }, 
  {
    nombre: "Milla Jovovich",
    nacimiento: "17-15-1975",
    peliculas: [
        "Saga Resident Evil", 
        "El quinto elemento", 
        "Zoolander", 
        "Los tres mosqueteros", 
        "Dirty Girl"
    ]
  }, 
];

/* Creamos una tabla HTML y la dejamos "abierta" */
let tablaDeActores:string = `
    <table width="750" border="1">
        <tr>
            <th width="250">Actor / Actriz</th>
            <th width="120">F.Nac</th>
            <th width="*">Películas</th>
        </tr>
`;

/* Recorremos cada objeto con dos forEach anidados, para poder recorrer los actores y, dentro de estos, sus películas. */
actores.forEach(function(actor){
    tablaDeActores += `
        <tr>
            <td valign="top">${actor.nombre}</td>
            <td valign="top">${actor.nacimiento}</td>
            <td valign="top"><ul> 
    `;
    actor.peliculas.forEach(function(pelicula){
        tablaDeActores += `<li>${pelicula}</li>`;
    });
    tablaDeActores += `</ul></td></tr>`;
});

/* Cerramos la tabla y la mostramos en el documento. */
tablaDeActores += `</table>`;
document.write(tablaDeActores);
